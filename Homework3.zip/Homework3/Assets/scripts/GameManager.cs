using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    [SerializeField] private GameObject ballDrop;
    public Vector3 spawnSpot = new Vector3(0, 2, 0);
    [SerializeField] private GameObject CubeDrop;
    public Vector3 spawnSpot2 = new Vector3(0, 2, 5);
    private int x = -9;


    // Start is called before the first frame update
    void Start()
    {
        Debug.Log("If you would like to see my trigger example. Walk into the pink box and it will print a message to the console");
        Debug.Log("If you would like to see my rigidbody movement example. press Q and watch every box spin");
        Debug.Log("If you would like to see my Raycasting example. Point the rheticle at the little balls and squares to see a change");
        Debug.Log("If you would like to see my colliders example click you mouse on the balls in front of you and they will move with an impulse");


        int i = 0;
        while (i < 25)
        {
            Instantiate(ballDrop, new Vector3(x,i,0), Quaternion.identity);
            Instantiate(CubeDrop, new Vector3(x, i, 5), Quaternion.identity);
            i++;
            x++;
        }
    }

    // Update is called once per frame
    void Update()
    {
        
    }

}
