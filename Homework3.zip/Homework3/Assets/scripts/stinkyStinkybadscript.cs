using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class stinkyStinkybadscript : MonoBehaviour
{

 

    public Rigidbody rigid;
    public Vector3 m_EulerAngleVelocity;
    // Start is called before the first frame update
    void Start()
    {
        rigid = GetComponent<Rigidbody>();
        m_EulerAngleVelocity = new Vector3(0, 500, 0);
    }

    // Update is called once per frame
    void Update()
    {
        
    }

    void FixedUpdate()
    {
        if(Input.GetKey(KeyCode.Q))
        {

            Quaternion deltaRotation = Quaternion.Euler(m_EulerAngleVelocity * Time.fixedDeltaTime);
            rigid.MoveRotation(rigid.rotation * deltaRotation);
        }
    }
}
